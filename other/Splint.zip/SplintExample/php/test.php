<?php
    require_once dirname(__DIR__) . '../../Splint/Splint.php';
